
# How to run Assignment 1
First make directory for outputs, i.e.:
`mkdir outputs`
## Isothermal wave:
`make`

## Isothermal Shock:
`make iso`

## Sod Shock:
`make sod`
